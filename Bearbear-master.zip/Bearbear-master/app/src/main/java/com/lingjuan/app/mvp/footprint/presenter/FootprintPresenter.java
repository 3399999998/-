package com.lingjuan.app.mvp.footprint.presenter;

/**
 * @author: TaoHui
 * @date: 2019/1/17
 */
public class FootprintPresenter {
}
